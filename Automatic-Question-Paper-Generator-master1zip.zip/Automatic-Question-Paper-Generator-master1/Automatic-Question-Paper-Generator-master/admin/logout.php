<?php
session_start();
unset ($_SESSION["librarian"]);
?>
<script type="text/javascript">
window.location="login.php";
</script>
